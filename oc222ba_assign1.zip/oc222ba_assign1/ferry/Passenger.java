/**
 * 
 */
package oc222ba_assign1.ferry;

/**
 * @author olgachristensen
 *
 */
public class Passenger {
	
	/*
	 * possible to add some info for a passenger, e.g. name, nationality, duty free tickets, etc.
	 */
	
	public Passenger() { }

}
