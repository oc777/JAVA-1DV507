package oc222ba_assign2.queue;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author olgachristensen
 *
 */
public abstract class TestQueue2 {
	public abstract Queue create();
	private static int test_count = 0;
	private Queue q;

	@Before
	public void setUp() {
		test_count++;
		System.out.println("Test "+ test_count);
		q = create();
	}
	
	@After
	public void tearDown() { }
	
		
	@Test
	public void testInitSize() {
		assertEquals(0, q.size());
	}
	
	@Test
	public void testIsEmpty() {
		assertTrue(q.isEmpty());
	}
	
	@Test
	public void testNotEmpty() {
		q.enqueue(9);
		assertFalse(q.isEmpty());
	}
	
	@Test 
	public void testEnqueueSize() {
		build(3);
		assertEquals(3, q.size());
	}
	
	@Test
	public void testDequeueSize() {
		int n = 3;
		build(n);
		q.dequeue();
		assertEquals(n-1, q.size());
	}
	
	@Test
	public void testDequeue() {
		q.enqueue(9);
		assertEquals(9, q.dequeue());
	}
	
	@Test (expected = NullPointerException.class)
	public void testDequeueErr() {
		q.dequeue();
	}
	
	@Test
	public void testFirst() {
		q.enqueue(3);
		assertEquals(3, q.first());
	}
	
	@Test (expected = NullPointerException.class)
	public void testFirstErr() {
		q.first();
	}
	
	@Test
	public void testLast() {
		q.enqueue(5);
		assertEquals(5, q.last());
	}
	
	@Test (expected = NullPointerException.class)
	public void testLastErr() {
		q.last();
	}
	
	@Test
	public void testToString() {
		build(3);
		assertEquals("Queue: 1, 1, 1", q.toString());
	}
	
	
	
	private Queue build(int n) {
		q = create();
		for(int i = 0; i < n; i++) {
			q.enqueue(1);
		}
		return q;
	}
	

}

class ArrayQueueTest extends QueueTest {
	public Queue create() {
		return new ArrayQueue();
	}
}

 class LinkedQueueTest extends QueueTest {
	public Queue create() {
		return new LinkedQueue();
	}
}
