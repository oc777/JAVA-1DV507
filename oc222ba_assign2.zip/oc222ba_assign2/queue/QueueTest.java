package oc222ba_assign2.queue;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * @author olgachristensen
 *
 */
public class QueueTest {
	private static int test_count = 0;
	private LinkedQueue q;

	@Before
	public void setUp() {
		test_count++;
		System.out.println("Test "+ test_count);
		q = new LinkedQueue();
	}
	
	@After
	public void tearDown() { }
	
		
	@Test
	public void testInitSize() {
		assertEquals(0, q.size());
	}
	
	@Test
	public void testIsEmpty() {
		assertTrue(q.isEmpty());
	}
	
	@Test
	public void testNotEmpty() {
		q.enqueue(9);
		assertFalse(q.isEmpty());
	}
	
	@Test 
	public void testEnqueueSize() {
		buildLQ(3);
		assertEquals(3, q.size());
	}
	
	@Test
	public void testDequeueSize() {
		int n = 3;
		buildLQ(n);
		q.dequeue();
		assertEquals(n-1, q.size());
	}
	
	@Test
	public void testDequeue() {
		q.enqueue(9);
		assertEquals(9, q.dequeue());
	}
	
	@Test (expected = NullPointerException.class)
	public void testDequeueErr() {
		q.dequeue();
	}
	
	@Test
	public void testFirst() {
		q.enqueue(3);
		assertEquals(3, q.first());
	}
	
	@Test (expected = NullPointerException.class)
	public void testFirstErr() {
		q.first();
	}
	
	@Test
	public void testLast() {
		q.enqueue(5);
		assertEquals(5, q.last());
	}
	
	@Test (expected = NullPointerException.class)
	public void testLastErr() {
		q.last();
	}
	
	@Test
	public void testToString() {
		buildLQ(3);
		assertEquals("Queue: 1, 1, 1", q.toString());
	}
	
	
	
	private LinkedQueue buildLQ(int n) {
		q = new LinkedQueue();
		for(int i = 0; i < n; i++) {
			q.enqueue(1);
		}
		return q;
	}
	

}
